import weather.WeatherAPI;

public class MyWeatherAPI extends WeatherAPI {
}
